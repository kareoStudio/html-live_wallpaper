package com.example;

import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;

public class PreviewActivity extends AppCompatActivity {

    private WebView webView;
    private LinearLayout errorLayout;
    private TextView tvError;
    private ProgressBar loadingProgress;
    private TextView tvPreviewInfo;
    private String currentPath;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeHelper.applyTheme(this);
        setContentView(R.layout.activity_preview);
        prefs = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE);

        ImageButton btnBack = findViewById(R.id.btn_back_preview);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        ImageButton btnInfo = findViewById(R.id.btn_info);
        if (btnInfo != null) {
            btnInfo.setOnClickListener(v -> showInfo());
        }

        errorLayout = findViewById(R.id.error_layout);
        tvError = findViewById(R.id.tv_error);
        loadingProgress = findViewById(R.id.loading_progress);
        tvPreviewInfo = findViewById(R.id.tv_preview_info);
        
        Button btnReload = findViewById(R.id.btn_preview_reload);
        Button btnApply = findViewById(R.id.btn_preview_apply);

        setupWebView();
        loadWallpaper();

        btnReload.setOnClickListener(v -> loadWallpaper());
        
        btnApply.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(this, HtmlWallpaperService.class));
                startActivity(intent);
            } catch (Exception e) {
                Intent intent = new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER);
                startActivity(intent);
            }
        });
    }

    private void showInfo() {
        if (currentPath == null) return;
        File file = new File(currentPath);
        File parent = file.getParentFile();
        long size = file.length();
        String sizeStr = WallpaperManagerApp.formatSize(size);
        
        String info = "File: " + file.getName() + "\n" +
                      "Folder: " + (parent != null ? parent.getName() : "") + "\n" +
                      "Size: " + sizeStr;
                      
        new AlertDialog.Builder(this)
            .setTitle("Wallpaper Info")
            .setMessage(info)
            .setPositiveButton("OK", null)
            .show();
    }

    private void setupWebView() {
        webView = WebViewHelper.createWebView(this, prefs, new WebViewHelper.Callback() {
            @Override
            public void onProgress(int progress) {
                if (progress < 100) {
                    loadingProgress.setVisibility(View.VISIBLE);
                } else {
                    loadingProgress.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTitle(String title) {
                tvPreviewInfo.setText("Title: " + title);
            }

            @Override
            public void onError(String error) {
                webView.setVisibility(View.GONE);
                errorLayout.setVisibility(View.VISIBLE);
                tvError.setText("Error: " + error);
            }

            @Override
            public void onFinished() {
                takeScreenshot();
            }
        });
        
        // Find placeholder in layout and add WebView
        WebView xmlWebView = findViewById(R.id.preview_webview);
        ViewGroup parent = (ViewGroup) xmlWebView.getParent();
        int index = parent.indexOfChild(xmlWebView);
        parent.removeView(xmlWebView);
        
        webView.setId(R.id.preview_webview);
        webView.setLayoutParams(xmlWebView.getLayoutParams());
        parent.addView(webView, index);
    }
    
    private void takeScreenshot() {
        if (currentPath == null || !currentPath.contains("wallpapers")) return;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                if (webView.getWidth() > 0 && webView.getHeight() > 0) {
                    Bitmap bitmap = Bitmap.createBitmap(webView.getWidth(), webView.getHeight(), Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    webView.draw(canvas);
                    
                    int targetW = 400;
                    int targetH = (int) (400f * webView.getHeight() / webView.getWidth());
                    Bitmap thumb = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true);
                    
                    File parent = new File(currentPath).getParentFile();
                    if (parent != null) {
                        File thumbFile = new File(parent, "thumb.jpg");
                        try (FileOutputStream out = new FileOutputStream(thumbFile)) {
                            thumb.compress(Bitmap.CompressFormat.JPEG, 85, out);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 1500);
    }

    private void loadWallpaper() {
        errorLayout.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        loadingProgress.setVisibility(View.VISIBLE);
        tvPreviewInfo.setText("Loading...");

        currentPath = prefs.getString("html_path", null);
        WebViewHelper.loadWallpaper(webView, prefs);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            ViewGroup parent = (ViewGroup) webView.getParent();
            if (parent != null) {
                parent.removeView(webView);
            }
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
