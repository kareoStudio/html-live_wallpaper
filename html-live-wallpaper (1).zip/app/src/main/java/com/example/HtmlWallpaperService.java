package com.example;

import android.app.Presentation;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.os.Bundle;
import android.service.wallpaper.WallpaperService;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.ViewGroup;
import android.webkit.WebView;

public class HtmlWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new HtmlEngine();
    }

    private class HtmlEngine extends Engine {
        private WebView webView;
        private VirtualDisplay virtualDisplay;
        private Presentation presentation;
        private SharedPreferences prefs;

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            prefs = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE);
        }

        private void createWebView(Context context) {
            if (webView != null) return;
            webView = WebViewHelper.createWebView(context, prefs, null);
            WebViewHelper.loadWallpaper(webView, prefs);
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            if (webView != null) {
                if (visible) {
                    WebViewHelper.loadWallpaper(webView, prefs);
                    webView.onResume();
                } else {
                    webView.onPause();
                }
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            
            releaseVirtualDisplay();

            DisplayManager displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int densityDpi = metrics.densityDpi;

            virtualDisplay = displayManager.createVirtualDisplay(
                    "WallpaperDisplay",
                    width,
                    height,
                    densityDpi,
                    holder.getSurface(),
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
            );

            if (virtualDisplay != null) {
                presentation = new Presentation(HtmlWallpaperService.this, virtualDisplay.getDisplay()) {
                    @Override
                    protected void onCreate(Bundle savedInstanceState) {
                        super.onCreate(savedInstanceState);
                        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                    }
                };

                createWebView(presentation.getContext());

                if (webView.getParent() != null) {
                    ((ViewGroup) webView.getParent()).removeView(webView);
                }
                presentation.setContentView(webView);
                
                try {
                    presentation.show();
                } catch (Exception e) {
                    Log.e("HtmlWallpaperService", "Error showing presentation", e);
                }
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            releaseVirtualDisplay();
            super.onSurfaceDestroyed(holder);
        }

        private void releaseVirtualDisplay() {
            if (presentation != null) {
                try {
                    presentation.dismiss();
                } catch (Exception e) {
                }
                presentation = null;
            }
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
        }

        @Override
        public void onDestroy() {
            releaseVirtualDisplay();
            if (webView != null) {
                webView.destroy();
                webView = null;
            }
            super.onDestroy();
        }
    }
}
