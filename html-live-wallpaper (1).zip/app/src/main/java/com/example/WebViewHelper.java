package com.example;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;

public class WebViewHelper {

    public interface Callback {
        void onProgress(int progress);
        void onTitle(String title);
        void onError(String error);
        void onFinished();
    }

    public static WebView createWebView(Context context, SharedPreferences prefs, Callback callback) {
        WebView webView = new WebView(context);
        WebSettings settings = webView.getSettings();
        
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        if (prefs.getBoolean("enable_cache", true)) {
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        } else {
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        }

        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setBackgroundColor(Color.TRANSPARENT);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (callback != null) callback.onProgress(newProgress);
            }
            
            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (callback != null) callback.onTitle(title);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    String err = error.getDescription().toString();
                    Log.e("WebViewHelper", "Error loading HTML: " + err);
                    if (callback != null) callback.onError(err);
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e("WebViewHelper", "Error loading HTML: " + description);
                if (callback != null) callback.onError(description);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (callback != null) callback.onFinished();
            }
        });

        return webView;
    }

    public static void loadWallpaper(WebView webView, SharedPreferences prefs) {
        if (webView == null) return;
        String path = prefs.getString("html_path", null);
        if (path != null) {
            File file = new File(path);
            if (file.exists()) {
                webView.loadUrl("file://" + file.getAbsolutePath());
                return;
            }
        }
        webView.loadUrl("file:///android_asset/index.html");
    }
}
