package com.example;

import java.io.File;

public class Wallpaper {
    public String id;
    public String name;
    public File folder;
    public File htmlFile;
    public File thumbFile;
    public long lastModified;
    public long size;
}
