package com.example;

import android.content.Context;
import androidx.documentfile.provider.DocumentFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class FileUtils {
    public static void copyDocumentFolder(Context context, DocumentFile sourceFolder, File destFolder) {
        if (!destFolder.exists()) {
            destFolder.mkdirs();
        }
        for (DocumentFile file : sourceFolder.listFiles()) {
            if (file.isDirectory()) {
                copyDocumentFolder(context, file, new File(destFolder, file.getName()));
            } else {
                copyFile(context, file, new File(destFolder, file.getName()));
            }
        }
    }

    private static void copyFile(Context context, DocumentFile sourceFile, File destFile) {
        try (InputStream in = context.getContentResolver().openInputStream(sourceFile.getUri());
             OutputStream out = new FileOutputStream(destFile)) {
            if (in == null) return;
            byte[] buf = new byte[8192];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
