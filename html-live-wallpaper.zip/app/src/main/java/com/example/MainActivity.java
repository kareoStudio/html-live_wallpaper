package com.example;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_PICK_ZIP = 1001;
    private static final int REQUEST_CODE_PICK_FOLDER = 1002;
    private TextView tvActiveWallpaper;
    private RecyclerView recyclerWallpapers;
    private WallpaperAdapter adapter;
    private List<Wallpaper> wallpaperList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ThemeHelper.applyTheme(this);
        setContentView(R.layout.activity_main);

        tvActiveWallpaper = findViewById(R.id.tv_active_wallpaper);
        Button btnImportZip = findViewById(R.id.btn_import_zip);
        Button btnImportFolder = findViewById(R.id.btn_import_folder);
        Button btnPreview = findViewById(R.id.btn_preview);
        Button btnApply = findViewById(R.id.btn_apply);
        ImageButton btnSettings = findViewById(R.id.btn_settings);
        recyclerWallpapers = findViewById(R.id.recycler_wallpapers);
        
        recyclerWallpapers.setLayoutManager(new GridLayoutManager(this, 2));

        updateActiveWallpaperText();
        loadLibrary();

        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        });

        btnImportZip.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("application/zip");
            startActivityForResult(intent, REQUEST_CODE_PICK_ZIP);
        });

        btnImportFolder.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(intent, REQUEST_CODE_PICK_FOLDER);
        });

        btnPreview.setOnClickListener(v -> {
            Intent intent = new Intent(this, PreviewActivity.class);
            startActivity(intent);
        });

        btnApply.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(this, HtmlWallpaperService.class));
                startActivity(intent);
            } catch (Exception e) {
                Intent intent = new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER);
                startActivity(intent);
            }
        });
    }

    private void loadLibrary() {
        wallpaperList = WallpaperManagerApp.getWallpapers(getFilesDir());
        if (adapter == null) {
            adapter = new WallpaperAdapter(wallpaperList, new WallpaperAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(Wallpaper wallpaper) {
                    getSharedPreferences("WallpaperPrefs", MODE_PRIVATE)
                        .edit()
                        .putString("html_path", wallpaper.htmlFile.getAbsolutePath())
                        .apply();
                    updateActiveWallpaperText();
                    Toast.makeText(MainActivity.this, "Selected: " + wallpaper.name, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onItemLongClick(Wallpaper wallpaper) {
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Wallpaper")
                        .setMessage("Are you sure you want to delete this wallpaper?")
                        .setPositiveButton("Yes", (dialog, which) -> {
                            ZipUtils.deleteRecursive(wallpaper.folder);
                            loadLibrary();
                        })
                        .setNegativeButton("No", null)
                        .show();
                }
            });
            recyclerWallpapers.setAdapter(adapter);
        } else {
            adapter.updateData(wallpaperList);
        }
    }

    private void updateActiveWallpaperText() {
        if (tvActiveWallpaper == null) return;
        String path = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE).getString("html_path", null);
        if (path != null) {
            File f = new File(path);
            String name = f.getParentFile() != null ? f.getParentFile().getName() : f.getName();
            if (name.equals("wallpaper_html")) name = "Imported Wallpaper";
            tvActiveWallpaper.setText(name);
        } else {
            tvActiveWallpaper.setText("Default Wallpaper");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateActiveWallpaperText();
        loadLibrary();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                if (requestCode == REQUEST_CODE_PICK_ZIP) {
                    importZip(uri);
                } else if (requestCode == REQUEST_CODE_PICK_FOLDER) {
                    importFolder(uri);
                }
            }
        }
    }

    private void importFolder(Uri treeUri) {
        ProgressDialog dialog = ProgressDialog.show(this, "Importing", "Copying files...", true, false);
        new Thread(() -> {
            try {
                DocumentFile pickedDir = DocumentFile.fromTreeUri(this, treeUri);
                if (pickedDir != null) {
                    File destDir = new File(new File(getFilesDir(), "wallpapers"), pickedDir.getName() + "_" + System.currentTimeMillis());
                    FileUtils.copyDocumentFolder(this, pickedDir, destDir);
                    
                    File htmlFile = WallpaperManagerApp.findHtmlFile(destDir);
                    
                    runOnUiThread(() -> {
                        dialog.dismiss();
                        if (htmlFile != null) {
                            getSharedPreferences("WallpaperPrefs", MODE_PRIVATE)
                                .edit()
                                .putString("html_path", htmlFile.getAbsolutePath())
                                .apply();
                            updateActiveWallpaperText();
                            loadLibrary();
                            Toast.makeText(this, "Folder import successful!", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "No valid HTML file found in folder", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    dialog.dismiss();
                    Toast.makeText(this, "Failed to import folder", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void importZip(Uri uri) {
        ProgressDialog dialog = ProgressDialog.show(this, "Importing", "Extracting files...", true, false);
        new Thread(() -> {
            try {
                File wpDir = new File(getFilesDir(), "wallpapers");
                File destDir = new File(wpDir, "ZIP_" + System.currentTimeMillis());
                destDir.mkdirs();
    
                ZipUtils.unzip(this, uri, destDir);
                
                File htmlFile = WallpaperManagerApp.findHtmlFile(destDir);
                
                runOnUiThread(() -> {
                    dialog.dismiss();
                    if (htmlFile != null) {
                        getSharedPreferences("WallpaperPrefs", MODE_PRIVATE)
                            .edit()
                            .putString("html_path", htmlFile.getAbsolutePath())
                            .apply();
                        updateActiveWallpaperText();
                        loadLibrary();
                        Toast.makeText(this, "ZIP import successful!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "No valid HTML found in ZIP", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    dialog.dismiss();
                    Toast.makeText(this, "Failed to import ZIP", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
}
