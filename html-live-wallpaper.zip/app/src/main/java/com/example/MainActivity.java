package com.example;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_PICK_ZIP = 1001;
    private TextView tvActiveWallpaper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvActiveWallpaper = findViewById(R.id.tv_active_wallpaper);
        Button btnImport = findViewById(R.id.btn_import);
        Button btnPreview = findViewById(R.id.btn_preview);
        Button btnApply = findViewById(R.id.btn_apply);
        ImageButton btnSettings = findViewById(R.id.btn_settings);
        
        updateActiveWallpaperText();

        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        });

        btnImport.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("application/zip");
            startActivityForResult(intent, REQUEST_CODE_PICK_ZIP);
        });

        btnPreview.setOnClickListener(v -> {
            Intent intent = new Intent(this, PreviewActivity.class);
            startActivity(intent);
        });

        btnApply.setOnClickListener(v -> {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, HtmlWallpaperService.class));
            startActivity(intent);
        });
    }

    private void updateActiveWallpaperText() {
        if (tvActiveWallpaper == null) return;
        String path = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE).getString("html_path", null);
        if (path != null) {
            File f = new File(path);
            String name = f.getParentFile() != null ? f.getParentFile().getName() : f.getName();
            if (name.equals("wallpaper_html")) name = "Custom Wallpaper";
            tvActiveWallpaper.setText(name);
        } else {
            tvActiveWallpaper.setText("Default Wallpaper");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateActiveWallpaperText();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_CODE_PICK_ZIP && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                importZip(uri);
            }
        }
    }

    private void importZip(Uri uri) {
        try {
            File destDir = new File(getFilesDir(), "wallpaper_html");
            if (destDir.exists()) {
                ZipUtils.deleteRecursive(destDir);
            }
            destDir.mkdirs();

            ZipUtils.unzip(this, uri, destDir);
            
            File htmlFile = findHtmlFile(destDir);
            
            if (htmlFile != null) {
                getSharedPreferences("WallpaperPrefs", MODE_PRIVATE)
                    .edit()
                    .putString("html_path", htmlFile.getAbsolutePath())
                    .apply();
                Toast.makeText(this, "Import successful!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No index.html or 1.html found in ZIP", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to import ZIP", Toast.LENGTH_LONG).show();
        }
    }
    
    private File findHtmlFile(File dir) {
        if (!dir.isDirectory()) return null;
        File index = new File(dir, "index.html");
        if (index.exists()) return index;
        File one = new File(dir, "1.html");
        if (one.exists()) return one;
        
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    File found = findHtmlFile(file);
                    if (found != null) return found;
                }
            }
        }
        return null;
    }
}
