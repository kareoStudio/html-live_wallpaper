package com.example;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.switchmaterial.SwitchMaterial;
import java.io.File;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);ThemeHelper.applyTheme(this);
        setContentView(R.layout.activity_settings);

        ImageButton btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        SharedPreferences prefs = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE);

        SwitchMaterial switchFps = findViewById(R.id.switch_fps);
        SwitchMaterial switchAudio = findViewById(R.id.switch_audio);
        SwitchMaterial switchTouch = findViewById(R.id.switch_touch);
        SwitchMaterial switchBatterySaver = findViewById(R.id.switch_battery_saver);
        SwitchMaterial switchCache = findViewById(R.id.switch_cache);

        switchFps.setChecked(prefs.getBoolean("fps_60", false));
        switchAudio.setChecked(prefs.getBoolean("enable_audio", false));
        switchTouch.setChecked(prefs.getBoolean("enable_touch", true));
        switchBatterySaver.setChecked(prefs.getBoolean("battery_saver", true));
        switchCache.setChecked(prefs.getBoolean("enable_cache", true));

        switchFps.setOnCheckedChangeListener((buttonView, isChecked) -> 
            prefs.edit().putBoolean("fps_60", isChecked).apply());

        switchAudio.setOnCheckedChangeListener((buttonView, isChecked) -> 
            prefs.edit().putBoolean("enable_audio", isChecked).apply());

        switchTouch.setOnCheckedChangeListener((buttonView, isChecked) -> 
            prefs.edit().putBoolean("enable_touch", isChecked).apply());

        switchBatterySaver.setOnCheckedChangeListener((buttonView, isChecked) -> 
            prefs.edit().putBoolean("battery_saver", isChecked).apply());
            
        switchCache.setOnCheckedChangeListener((buttonView, isChecked) -> 
            prefs.edit().putBoolean("enable_cache", isChecked).apply());
            
        findViewById(R.id.btn_theme_light).setOnClickListener(v -> {
            prefs.edit().putString("theme", "light").apply();
            ThemeHelper.applyTheme(this);
        });
        findViewById(R.id.btn_theme_dark).setOnClickListener(v -> {
            prefs.edit().putString("theme", "dark").apply();
            ThemeHelper.applyTheme(this);
        });
        findViewById(R.id.btn_theme_system).setOnClickListener(v -> {
            prefs.edit().putString("theme", "system").apply();
            ThemeHelper.applyTheme(this);
        });

        Button btnReload = findViewById(R.id.btn_reload);
        btnReload.setOnClickListener(v -> {
            prefs.edit().putLong("reload_trigger", System.currentTimeMillis()).apply();
            Toast.makeText(this, "Reload trigger sent", Toast.LENGTH_SHORT).show();
        });

        Button btnClearCache = findViewById(R.id.btn_clear_cache);
        btnClearCache.setOnClickListener(v -> {
            try {
                File dir = getCacheDir();
                ZipUtils.deleteRecursive(dir);
                Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
