package com.example;

import android.content.Context;
import android.net.Uri;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class ZipUtils {

    public static void unzip(Context context, Uri zipUri, File targetDirectory) throws Exception {
        InputStream is = context.getContentResolver().openInputStream(zipUri);
        ZipInputStream zis = new ZipInputStream(new BufferedInputStream(is));
        ZipEntry ze;

        while ((ze = zis.getNextEntry()) != null) {
            File file = new File(targetDirectory, ze.getName());
            File dir = ze.isDirectory() ? file : file.getParentFile();

            if (!dir.isDirectory() && !dir.mkdirs()) {
                throw new Exception("Failed to ensure directory: " + dir.getAbsolutePath());
            }

            if (ze.isDirectory()) {
                continue;
            }

            FileOutputStream fout = new FileOutputStream(file);
            try {
                byte[] buffer = new byte[8192];
                int count;
                while ((count = zis.read(buffer)) != -1) {
                    fout.write(buffer, 0, count);
                }
            } finally {
                fout.close();
            }
        }
        zis.close();
    }

    public static void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            for (File child : fileOrDirectory.listFiles()) {
                deleteRecursive(child);
            }
        }
        fileOrDirectory.delete();
    }
}
