package com.example;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class WallpaperManagerApp {
    public static List<Wallpaper> getWallpapers(File rootDir) {
        List<Wallpaper> list = new ArrayList<>();
        File wpDir = new File(rootDir, "wallpapers");
        if (!wpDir.exists()) wpDir.mkdirs();
        
        File[] folders = wpDir.listFiles();
        if (folders != null) {
            for (File f : folders) {
                if (f.isDirectory()) {
                    Wallpaper w = new Wallpaper();
                    w.id = f.getName();
                    w.name = f.getName(); 
                    w.folder = f;
                    w.htmlFile = findHtmlFile(f);
                    w.thumbFile = new File(f, "thumb.jpg");
                    w.lastModified = f.lastModified();
                    w.size = getFolderSize(f);
                    if (w.htmlFile != null) {
                        list.add(w);
                    }
                }
            }
        }
        return list;
    }
    
    public static File findHtmlFile(File dir) {
        if (!dir.isDirectory()) return null;
        String[] priorities = {"index.html", "index.htm", "1.html", "main.html"};
        for (String p : priorities) {
            File f = new File(dir, p);
            if (f.exists()) return f;
        }
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    File found = findHtmlFile(file);
                    if (found != null) return found;
                } else if (file.getName().endsWith(".html") || file.getName().endsWith(".htm")) {
                    return file;
                }
            }
        }
        return null;
    }
    
    public static long getFolderSize(File dir) {
        long size = 0;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    size += getFolderSize(file);
                } else {
                    size += file.length();
                }
            }
        }
        return size;
    }
    
    public static String formatSize(long size) {
        if (size <= 0) return "0 B";
        final String[] units = new String[] { "B", "KB", "MB", "GB", "TB" };
        int digitGroups = (int) (Math.log10(size) / Math.log10(1024));
        return String.format("%.1f %s", size / Math.pow(1024, digitGroups), units[digitGroups]);
    }
}
