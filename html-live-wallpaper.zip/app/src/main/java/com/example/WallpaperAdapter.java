package com.example;

import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WallpaperAdapter extends RecyclerView.Adapter<WallpaperAdapter.ViewHolder> {
    private List<Wallpaper> wallpapers;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Wallpaper wallpaper);
        void onItemLongClick(Wallpaper wallpaper);
    }

    public WallpaperAdapter(List<Wallpaper> wallpapers, OnItemClickListener listener) {
        this.wallpapers = wallpapers;
        this.listener = listener;
    }

    public void updateData(List<Wallpaper> newWallpapers) {
        this.wallpapers = newWallpapers;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_wallpaper, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Wallpaper w = wallpapers.get(position);
        holder.tvTitle.setText(w.name);
        holder.tvSize.setText(WallpaperManagerApp.formatSize(w.size));
        
        if (w.thumbFile.exists()) {
            holder.imgThumb.setImageBitmap(BitmapFactory.decodeFile(w.thumbFile.getAbsolutePath()));
        } else {
            holder.imgThumb.setImageDrawable(null);
            holder.imgThumb.setBackgroundColor(0xFF333333);
        }
        
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onItemClick(w);
        });
        holder.itemView.setOnLongClickListener(v -> {
            if (listener != null) listener.onItemLongClick(w);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return wallpapers != null ? wallpapers.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgThumb;
        TextView tvTitle;
        TextView tvSize;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgThumb = itemView.findViewById(R.id.img_thumb);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvSize = itemView.findViewById(R.id.tv_size);
        }
    }
}
