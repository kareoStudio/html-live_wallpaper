package com.example;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;

public class HtmlWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new HtmlEngine();
    }

    private class HtmlEngine extends Engine {
        private WebView webView;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean visible = false;
        private int width = 0;
        private int height = 0;
        private SharedPreferences prefs;
        private long lastReloadTrigger = 0;

        private final Runnable drawRunnable = new Runnable() {
            @Override
            public void run() {
                draw();
            }
        };

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            prefs = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE);
            
            handler.post(() -> {
                webView = new WebView(HtmlWallpaperService.this);
                WebSettings settings = webView.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setDomStorageEnabled(true);
                settings.setAllowFileAccess(true);
                settings.setAllowFileAccessFromFileURLs(true);
                settings.setAllowUniversalAccessFromFileURLs(true);
                settings.setMediaPlaybackRequiresUserGesture(false);
                
                // Enable hardware acceleration for WebView if possible
                webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                webView.setBackgroundColor(0x000000);

                webView.setWebViewClient(new WebViewClient() {
                    @Override
                    public void onPageFinished(WebView view, String url) {
                        super.onPageFinished(view, url);
                        if (visible) {
                            draw();
                        }
                    }
                });

                loadWallpaper();
            });
        }

        private void loadWallpaper() {
            String path = prefs.getString("html_path", null);
            if (path != null) {
                File file = new File(path);
                if (file.exists()) {
                    webView.loadUrl("file://" + file.getAbsolutePath());
                    return;
                }
            }
            webView.loadUrl("file:///android_asset/index.html");
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (visible) {
                checkPreferences();
                handler.post(() -> webView.onResume());
                handler.post(drawRunnable);
            } else {
                handler.post(() -> webView.onPause());
                handler.removeCallbacks(drawRunnable);
            }
        }

        private void checkPreferences() {
            long reloadTrigger = prefs.getLong("reload_trigger", 0);
            if (reloadTrigger > lastReloadTrigger) {
                lastReloadTrigger = reloadTrigger;
                handler.post(this::loadWallpaper);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            this.width = width;
            this.height = height;
            
            handler.post(() -> {
                webView.layout(0, 0, width, height);
                webView.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
            });
            draw();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            visible = false;
            handler.removeCallbacks(drawRunnable);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            handler.post(() -> {
                if (webView != null) {
                    webView.destroy();
                    webView = null;
                }
            });
        }

        private void draw() {
            if (visible && webView != null && width > 0 && height > 0) {
                SurfaceHolder holder = getSurfaceHolder();
                Canvas canvas = null;
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        canvas = holder.lockHardwareCanvas();
                    } else {
                        canvas = holder.lockCanvas();
                    }
                    if (canvas != null) {
                        webView.draw(canvas);
                    }
                } finally {
                    if (canvas != null) {
                        holder.unlockCanvasAndPost(canvas);
                    }
                }

                handler.removeCallbacks(drawRunnable);
                
                boolean fps60 = prefs.getBoolean("fps_60", false);
                boolean batterySaver = prefs.getBoolean("battery_saver", true);
                
                long delay = fps60 ? 16 : 33;
                if (batterySaver && !fps60) {
                    delay = 50; // 20 FPS for battery saver if not 60 fps
                }

                if (visible) {
                    handler.postDelayed(drawRunnable, delay);
                }
            }
        }
    }
}
