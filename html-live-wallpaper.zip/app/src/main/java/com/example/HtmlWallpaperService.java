package com.example;

import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;

public class HtmlWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new HtmlEngine();
    }

    private class HtmlEngine extends Engine {
        private WebView webView;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean visible = false;
        private int width = 0;
        private int height = 0;
        private SharedPreferences prefs;
        private long lastReloadTrigger = 0;
        private boolean isPageLoaded = false;

        private final Runnable drawRunnable = new Runnable() {
            @Override
            public void run() {
                draw();
            }
        };

        @Override
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            prefs = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE);
            
            handler.post(() -> {
                try {
                    webView = new WebView(HtmlWallpaperService.this);
                    WebSettings settings = webView.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setAllowFileAccess(true);
                    settings.setAllowContentAccess(true);
                    settings.setAllowFileAccessFromFileURLs(true);
                    settings.setAllowUniversalAccessFromFileURLs(true);
                    settings.setLoadsImagesAutomatically(true);
                    settings.setMediaPlaybackRequiresUserGesture(false);
                    
                    if (prefs.getBoolean("enable_cache", true)) {
                        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
                    } else {
                        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
                    }
                    
                    webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                    webView.setBackgroundColor(0x000000);
    
                    webView.setWebChromeClient(new WebChromeClient());
                    webView.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView view, String url) {
                            super.onPageFinished(view, url);
                            isPageLoaded = true;
                            if (visible) {
                                draw();
                            }
                        }
                        
                        @Override
                        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                            Log.e("HtmlWallpaperService", "WebView Error: " + error.getDescription());
                        }
                    });
    
                    loadWallpaper();
                } catch (Exception e) {
                    Log.e("HtmlWallpaperService", "Error creating WebView", e);
                }
            });
        }

        private void loadWallpaper() {
            isPageLoaded = false;
            String path = prefs.getString("html_path", null);
            if (path != null) {
                File file = new File(path);
                if (file.exists()) {
                    webView.loadUrl("file://" + file.getAbsolutePath());
                    return;
                }
            }
            webView.loadUrl("file:///android_asset/index.html");
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (visible) {
                checkPreferences();
                if (webView != null) {
                    handler.post(() -> webView.onResume());
                }
                handler.post(drawRunnable);
            } else {
                if (webView != null) {
                    handler.post(() -> webView.onPause());
                }
                handler.removeCallbacks(drawRunnable);
            }
        }

        private void checkPreferences() {
            long reloadTrigger = prefs.getLong("reload_trigger", 0);
            if (reloadTrigger > lastReloadTrigger) {
                lastReloadTrigger = reloadTrigger;
                handler.post(this::loadWallpaper);
            }
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            this.width = width;
            this.height = height;
            
            if (webView != null) {
                handler.post(() -> {
                    try {
                        webView.layout(0, 0, width, height);
                        int widthSpec = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
                        int heightSpec = View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY);
                        webView.measure(widthSpec, heightSpec);
                    } catch (Exception e) {
                        Log.e("HtmlWallpaperService", "Error in onSurfaceChanged", e);
                    }
                });
            }
            draw();
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            visible = false;
            handler.removeCallbacks(drawRunnable);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            handler.post(() -> {
                if (webView != null) {
                    try {
                        webView.destroy();
                        webView = null;
                    } catch (Exception e) {
                        Log.e("HtmlWallpaperService", "Error destroying WebView", e);
                    }
                }
            });
        }

        private void draw() {
            if (visible && webView != null && width > 0 && height > 0 && isPageLoaded) {
                handler.removeCallbacks(drawRunnable);
                
                SurfaceHolder holder = getSurfaceHolder();
                Canvas canvas = null;
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        canvas = holder.lockHardwareCanvas();
                    }
                    if (canvas == null) {
                        canvas = holder.lockCanvas();
                    }
                    if (canvas != null) {
                        // Measure and layout before draw to prevent blank render
                        webView.layout(0, 0, width, height);
                        int widthSpec = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
                        int heightSpec = View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY);
                        webView.measure(widthSpec, heightSpec);
                        webView.draw(canvas);
                    }
                } catch (Exception e) {
                    Log.e("HtmlWallpaperService", "Error in draw", e);
                } finally {
                    if (canvas != null) {
                        try {
                            holder.unlockCanvasAndPost(canvas);
                        } catch (Exception e) {
                            Log.e("HtmlWallpaperService", "Error unlocking canvas", e);
                        }
                    }
                }

                boolean fps60 = prefs.getBoolean("fps_60", false);
                boolean batterySaver = prefs.getBoolean("battery_saver", true);
                
                long delay = fps60 ? 16 : 33;
                if (batterySaver && !fps60) {
                    delay = 50; // 20 FPS for battery saver if not 60 fps
                }

                if (visible) {
                    handler.postDelayed(drawRunnable, delay);
                }
            } else if (visible && webView != null && width > 0 && height > 0) {
                // Not loaded yet, try again soon
                handler.removeCallbacks(drawRunnable);
                handler.postDelayed(drawRunnable, 100);
            }
        }
    }
}
