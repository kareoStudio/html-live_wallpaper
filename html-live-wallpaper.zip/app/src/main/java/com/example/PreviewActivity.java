package com.example;

import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;

public class PreviewActivity extends AppCompatActivity {

    private WebView webView;
    private LinearLayout errorLayout;
    private TextView tvError;
    private ProgressBar loadingProgress;
    private TextView tvPreviewInfo;
    private String currentPath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);ThemeHelper.applyTheme(this);
        setContentView(R.layout.activity_preview);

        ImageButton btnBack = findViewById(R.id.btn_back_preview);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        ImageButton btnInfo = findViewById(R.id.btn_info);
        if (btnInfo != null) {
            btnInfo.setOnClickListener(v -> showInfo());
        }

        webView = findViewById(R.id.preview_webview);
        errorLayout = findViewById(R.id.error_layout);
        tvError = findViewById(R.id.tv_error);
        loadingProgress = findViewById(R.id.loading_progress);
        tvPreviewInfo = findViewById(R.id.tv_preview_info);
        
        Button btnReload = findViewById(R.id.btn_preview_reload);
        Button btnApply = findViewById(R.id.btn_preview_apply);

        setupWebView();
        loadWallpaper();

        btnReload.setOnClickListener(v -> loadWallpaper());
        
        btnApply.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(this, HtmlWallpaperService.class));
                startActivity(intent);
            } catch (Exception e) {
                Intent intent = new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER);
                startActivity(intent);
            }
        });
    }

    private void showInfo() {
        if (currentPath == null) return;
        File file = new File(currentPath);
        File parent = file.getParentFile();
        long size = file.length();
        String sizeStr = WallpaperManagerApp.formatSize(size);
        
        String info = "File: " + file.getName() + "\n" +
                      "Folder: " + (parent != null ? parent.getName() : "") + "\n" +
                      "Size: " + sizeStr;
                      
        new AlertDialog.Builder(this)
            .setTitle("Wallpaper Info")
            .setMessage(info)
            .setPositiveButton("OK", null)
            .show();
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) {
                    loadingProgress.setVisibility(View.VISIBLE);
                } else {
                    loadingProgress.setVisibility(View.GONE);
                }
            }
            
            @Override
            public void onReceivedTitle(WebView view, String title) {
                tvPreviewInfo.setText("Title: " + title);
            }
        });
        
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e("PreviewActivity", "Error loading HTML: " + description + " URL: " + failingUrl);
                webView.setVisibility(View.GONE);
                errorLayout.setVisibility(View.VISIBLE);
                tvError.setText("Error: " + description);
            }
            
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    Log.e("PreviewActivity", "Error loading HTML: " + error.getDescription());
                    webView.setVisibility(View.GONE);
                    errorLayout.setVisibility(View.VISIBLE);
                    tvError.setText("Error: " + error.getDescription());
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                takeScreenshot();
            }
        });
    }
    
    private void takeScreenshot() {
        if (currentPath == null || !currentPath.contains("wallpapers")) return;
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                if (webView.getWidth() > 0 && webView.getHeight() > 0) {
                    Bitmap bitmap = Bitmap.createBitmap(webView.getWidth(), webView.getHeight(), Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    webView.draw(canvas);
                    
                    int targetW = 400;
                    int targetH = (int) (400f * webView.getHeight() / webView.getWidth());
                    Bitmap thumb = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true);
                    
                    File parent = new File(currentPath).getParentFile();
                    if (parent != null) {
                        File thumbFile = new File(parent, "thumb.jpg");
                        try (FileOutputStream out = new FileOutputStream(thumbFile)) {
                            thumb.compress(Bitmap.CompressFormat.JPEG, 85, out);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 1500); // Wait for animations
    }

    private void loadWallpaper() {
        errorLayout.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        loadingProgress.setVisibility(View.VISIBLE);
        tvPreviewInfo.setText("Loading...");

        currentPath = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE).getString("html_path", null);
        if (currentPath != null) {
            File file = new File(currentPath);
            if (file.exists()) {
                webView.loadUrl("file://" + file.getAbsolutePath());
                return;
            }
        }
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
