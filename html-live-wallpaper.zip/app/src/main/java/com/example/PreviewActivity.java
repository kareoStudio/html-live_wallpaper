package com.example;

import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class PreviewActivity extends AppCompatActivity {

    private WebView webView;
    private LinearLayout errorLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        ImageButton btnBack = findViewById(R.id.btn_back_preview);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        webView = findViewById(R.id.preview_webview);
        errorLayout = findViewById(R.id.error_layout);
        Button btnReload = findViewById(R.id.btn_preview_reload);
        Button btnApply = findViewById(R.id.btn_preview_apply);

        setupWebView();
        loadWallpaper();

        btnReload.setOnClickListener(v -> loadWallpaper());
        
        btnApply.setOnClickListener(v -> {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, HtmlWallpaperService.class));
            startActivity(intent);
        });
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                webView.setVisibility(View.GONE);
                errorLayout.setVisibility(View.VISIBLE);
            }
        });
    }

    private void loadWallpaper() {
        errorLayout.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);

        String path = getSharedPreferences("WallpaperPrefs", MODE_PRIVATE).getString("html_path", null);
        if (path != null) {
            File file = new File(path);
            if (file.exists()) {
                webView.loadUrl("file://" + file.getAbsolutePath());
                return;
            }
        }
        webView.loadUrl("file:///android_asset/index.html");
    }
}
